import UserRecipes from "./UserRecipes";
import RecipeItem from "./Recipe";

interface RecipesProps {
    recipes: {
        id: string;
        name: string;
        description: string;
        date: string;
        image: string;
        tags?: string[];
        user: {
            name: string;
            image?: string;
        }
    }[]
}

function Recipes({ recipes }: RecipesProps) {
    return (
        <div className="max-w-3xl m-auto flex flex-col items-center gap-6">
            <UserRecipes />
            {recipes.map(recipe => (
                <RecipeItem
                    key={recipe.id}
                    id={recipe.id}
                    name={recipe.name}
                    description={recipe.description}
                    img={recipe.image}
                    date={recipe.date}
                    account={recipe.user}
                />
            ))}
        </div>
    )
}

export default Recipes;