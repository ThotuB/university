import Layout from 'components/layouts/navigation/Layout';

export default function Settings() {
    return (
        <Layout>
            <div className="rounded-lg border-4 border-black">
                <div>
                    User
                </div>
                <div>

                </div>
            </div>
        </Layout>
    )
}