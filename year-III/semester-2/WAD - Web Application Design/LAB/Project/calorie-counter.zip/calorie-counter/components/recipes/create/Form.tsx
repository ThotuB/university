import InfoField from "./InfoFields";
import IngredientField from "./IngredientField";
import StepField from "./StepField";
import Divider from "components/common/Divider";
import { useState } from "react";
import Button from "components/common/Button";
import { useUser } from "contexts/UserContext";

interface FormProps {
    onCreate: (recipe: Recipe) => void;
}

export interface Recipe extends Info {
    ingredients: Ingredient[];
    steps: string[];
    user: {
        id?: string;
        name?: string;
        image?: string;
    }
}

export interface Info {
    name: string;
    description: string;
    image?: string;
}

export interface Ingredient {
    id: string;
    name: string;
    quantity: string;
}

export default ({ onCreate }: FormProps) => {
    const [info, setInfo] = useState<Info>({} as Info);
    const [ingredients, setIngredients] = useState<Ingredient[]>([]);
    const [steps, setSteps] = useState<string[]>([]);

    const { user } = useUser();

    const handleCreate = () => {
        const recipe: Recipe = {
            ...info,
            ingredients,
            steps,
            user: {
                id: user?.uid,
                name: user?.displayName,
                image: user?.photoURL
            }
        };
        onCreate(recipe);
    }

    return (
        <div className="w-full bg-gray-100 rounded-md border p-4 flex flex-col gap-6">
            <InfoField onSave={setInfo} />

            <Divider />

            <IngredientField onSave={setIngredients} />

            <Divider />

            <StepField onSave={setSteps} />

            <Divider />

            <Button className="rounded-2xl"
                onClick={handleCreate}
            >
                CREATE RECIPE
            </Button>
        </div>
    );
}