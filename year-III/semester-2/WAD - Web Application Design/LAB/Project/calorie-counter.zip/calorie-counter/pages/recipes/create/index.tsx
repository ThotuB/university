import RecipeForm from 'components/recipes/create/Form'
import Layout from 'components/layouts/navigation/Layout'
import { Recipe } from 'components/recipes/create/Form'
import axios from 'axios';
import Router from 'next/router';

export default function Index() {
    async function handleCreate(recipe: Recipe) {
        await axios.post<Recipe>('/api/recipes', recipe);

        Router.push('/recipes');
    }

    return (
        <Layout>
            <RecipeForm onCreate={handleCreate} />
        </Layout>
    );
}