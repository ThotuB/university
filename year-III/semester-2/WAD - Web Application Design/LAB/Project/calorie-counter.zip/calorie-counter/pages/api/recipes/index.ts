import { MongoClient } from 'mongodb';
import { NextApiRequest, NextApiResponse } from 'next';

type GetData = {
    entries: number;
    pages: number;
    recipes: {
        id: string;
        name: string;
        description: string;
        image: File;
        user: {
            id: string;
            name: string;
            image?: string;
        }
    }[]
}

type PostData = {
    message: string;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse<GetData | PostData>) {
    if (req.method === 'GET') {
        const { pageNumber, pageSize } = req.query;
        const page = parseInt(pageNumber as string, 10) || 0;
        const size = parseInt(pageSize as string, 10) || 10;

        const client = await MongoClient.connect(
            'mongodb+srv://admin:WF0qDFsvY6ux716Q@thotu.lmwwa.mongodb.net/recipes?retryWrites=true&w=majority'
        );
        const db = client.db();

        const collection = db.collection('recipes');

        const result = await collection
            .find()
            .skip(page > 0 ? (page - 1) * size : 0)
            .limit(size)
            .toArray();
        const total = await collection.countDocuments();

        client.close()

        res.status(200).json({
            entries: total,
            pages: Math.ceil(total / size),
            recipes: result.map(recipe => {
                return {
                    id: recipe._id.toString(),
                    name: recipe.name,
                    description: recipe.description,
                    image: recipe.image,
                    user: {
                        id: recipe.user.userId,
                        name: recipe.user.name,
                        image: recipe.user.image
                    }
                }
            })
        })
    }

    if (req.method === 'POST') {
        const data = req.body;

        const client = await MongoClient.connect(
            'mongodb+srv://admin:WF0qDFsvY6ux716Q@thotu.lmwwa.mongodb.net/recipes?retryWrites=true&w=majority'
        );
        const db = client.db();

        const collection = db.collection('recipes');

        const result = await collection.insertOne(data)

        console.log(result)

        client.close()

        res.status(201).json({
            message: 'Recipe added',
        })
    }
}
