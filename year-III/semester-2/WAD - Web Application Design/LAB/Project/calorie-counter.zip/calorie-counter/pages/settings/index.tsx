import Settings from '../../components/settings/Settings';

export default function Index() {
    return (
        <Settings />
    )
}