import Loading from "components/common/Loading";
import TextField from "../../components/common/TextField";
import Pagination from "components/common/Pagination";

import { useState, useEffect } from "react";
import React from "react";

export default function Index() {

    return (
        <Loading />
    );
}