import Home from '../../components/home/Home'
import Layout from '../../components/layouts/navigation/Layout';

export default function Index() {
    return (
        <Layout>
            <Home />
        </Layout>
    );
}