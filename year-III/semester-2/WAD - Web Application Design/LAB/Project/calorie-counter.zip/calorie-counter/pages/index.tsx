import Auth from 'components/auth/Auth'

export default function Index() {
    return (
        <Auth />
    );
}