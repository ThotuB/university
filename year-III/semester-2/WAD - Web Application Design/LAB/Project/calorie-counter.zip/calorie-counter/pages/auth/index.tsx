import CreateAccount from '../../components/auth/Auth'

export default function Index() {
    return (
        <CreateAccount />
    )
}