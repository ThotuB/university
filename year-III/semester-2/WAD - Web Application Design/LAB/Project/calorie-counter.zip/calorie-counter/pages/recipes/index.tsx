import Recipes from 'components/recipes/Recipes'
import Layout from 'components/layouts/navigation/Layout'
import axios from 'axios'
import Pagination from 'components/common/Pagination'
import { useEffect, useState } from 'react'
import Loading from 'components/common/Loading'

export default () => {
    const [recipes, setRecipes] = useState([])
    const [page, setPage] = useState(1)
    const [count, setCount] = useState(0)
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        const url = `http://localhost:3000/api/recipes`
        const query = {
            params: {
                pageNumber: page,
                pageSize: 10
            }
        }

        setLoading(true)
        axios.get(url, query)
            .then(res => {
                setRecipes(res.data.recipes)
                setCount(res.data.pages)
                setLoading(false)
            })
            .catch(err => {
                console.log(err)
            })

    }, [page])

    return (
        <Layout>
            {loading ? <Loading /> : <Recipes recipes={recipes} />}
            <Pagination count={count} page={page} onPageChange={setPage} />
        </Layout>
    )
}