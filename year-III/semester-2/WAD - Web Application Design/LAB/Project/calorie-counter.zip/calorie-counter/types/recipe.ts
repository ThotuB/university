export interface IRecipe {
    id: string;
    name: string;
    description: string;
    image: string;
    ingredients: {
        id: string;
        name: string;
        quantity: number;
    }[]
    steps?: string[];
    user: {
        id: string;
        name: string;
        image: string;
    }
}