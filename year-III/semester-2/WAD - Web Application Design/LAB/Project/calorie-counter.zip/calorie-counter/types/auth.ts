export interface Auth {
    username: string;
    email: string;
    password: string;
    salt: string;
}