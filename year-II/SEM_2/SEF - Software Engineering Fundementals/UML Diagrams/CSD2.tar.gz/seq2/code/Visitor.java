public interface Visitor {
    public void visit(Numar n);
    public void visit(Suma s);
    public void visit(Inmultire i);
}