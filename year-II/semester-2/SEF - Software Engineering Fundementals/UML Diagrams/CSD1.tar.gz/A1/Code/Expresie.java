public abstract class Expresie {

    public abstract void accept(Visitor v);

}